bl_info = {
    "name": "io_scene_CSGO",
    "category": "Import-Export",
    "author": "adenex",
    "version": (0, 0, 1),
    "blender": (2, 90, 0),
    "description": "This tool can convert CS:GO's .QC files to .FBX, clean and export your scene",
    "location": "File > Import, Side Panel"
}

import bpy
import re
import time
import json
from bpy.types import Operator, Panel
from bpy.props import (
    StringProperty,
    BoolProperty,
    FloatProperty,
    CollectionProperty,
)
from bpy_extras.io_utils import (
    ImportHelper,
    ExportHelper
)
from . import Convert_QC

def menu_draw_convert(self, context):
    self.layout.operator("exp.qc_smd_cnv", text="Batch convert CSGO's QC files")

PROPS = [
    ('sp_float_value', bpy.props.FloatProperty(name="Float value", min=0.001, max=1000.0, default=0.0)),
    ('sp_bool_value', bpy.props.BoolProperty(name="Bool value", description="", default=False, )),
    ('sp_string_value', bpy.props.StringProperty(name='String value', description='', default='value', )),
    ('sp_int_value', bpy.props.IntProperty(name='Int value', description='', min=0, max=1000, soft_min=0, soft_max=1000, default=0, )),

    ('remove_w_knives', bpy.props.BoolProperty(name='Remove w_knives', default=True, description='Deletes all knives (except pov)')),
    ('remove_dropped_knives', bpy.props.BoolProperty(name='Remove *dropped* knives', default=True, description='Deletes all *dropped* knives')),
    ('remove_w_guns', bpy.props.BoolProperty(name='Remove w_guns', default=True, description='Deletes all guns (except pov)')),
    ('remove_dropped_guns', bpy.props.BoolProperty(name='Remove *dropped* guns', default=False, description='Deletes all *dropped* guns')),
    ('remove_w_pistols', bpy.props.BoolProperty(name='Remove w_pistols', default=True, description='Deletes all pistols (except pov)')),
    ('remove_dropped_pistols', bpy.props.BoolProperty(name='Remove *dropped* pistols', default=False, description='Deletes all *dropped* pistols')),
    ('remove_w_nades', bpy.props.BoolProperty(name='Remove nades', default=True, description='Deletes all grenades (except pov)')),
    ('remove_dropped_nades', bpy.props.BoolProperty(name='Remove *dropped* nades', default=True, description='Deletes all *dropped* grenades')),
    ('remove_w_c4', bpy.props.BoolProperty(name='Remove c4', default=True, description='Deletes c4 (except pov)')),
    ('remove_dropped_c4', bpy.props.BoolProperty(name='Remove *dropped* c4', default=True, description='Deletes *dropped* c4')),
    ('remove_pov', bpy.props.BoolProperty(name='Remove POV', default=False, description='Completely removes POV (viewmodels)')),
    ('remove_duplicates', bpy.props.BoolProperty(name='Remove duplicates', default=True, description='Removes all duplicated gloves and sleeves')),
    ('remove_misc', bpy.props.BoolProperty(name='Remove useless models', default=True, description='Removes stickers, defuser kits and stattrack models')),
    ('place_animations', bpy.props.BoolProperty(name='Place all animations at (0,0,0)', default=True, description='Prevents animations from appearing in other sequences. This option will take some time to process')),
    ('offset', bpy.props.IntProperty(name='Z Offset', default=-5)),
]


def fixer():  # fix bad naming
    bpy.ops.object.select_all(action='DESELECT')
    for obj in bpy.context.scene.objects:
        if re.match(r'afx.\w+.\w+.+', obj.name):
            obj.name = re.sub(r'(afx.\w+.\w+)(.+)', r'\1.mdl', obj.name)


def w_knives():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* w_knife_*[!d].mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def w_knives_dropped():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* w_knife_*dropped.mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def w_guns():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* w_rif_*[!d].mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='* w_mach_*[!d].mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='* w_shot_*[!d].mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='* w_smg_*[!d].mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='* w_snip_*[!d].mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def w_guns_dropped():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* w_rif_*dropped.mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='* w_mach_*dropped.mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='* w_shot_*dropped.mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='* w_smg_*dropped.mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='* w_snip_*dropped.mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def w_pistols():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* w_pist_*[!d].mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def w_pistols_dropped():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* w_pist_*dropped.mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def w_nades():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* w_eq_*[!d].mdl**', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def w_nades_dropped():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* w_eq_*dropped.mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def w_c4():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* w_ied.mdl', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def w_c4_dropped():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* w_ied_dropped.mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def pov():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* v_*', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def duplicates():
    def finder(pat):
        bpy.ops.object.select_all(action='DESELECT')
        bpy.ops.object.select_pattern(pattern=pat, case_sensitive=False, extend=True)
        selected_anims = bpy.context.selected_objects
        sel_anims = []
        for i in selected_anims:
            sel_anims.append(i.name)
        if len(sel_anims) > 1:
            del_list = sel_anims[1:]
            bpy.ops.object.select_all(action='DESELECT')
            for a in del_list:
                bpy.ops.object.select_pattern(pattern=a, case_sensitive=False, extend=True)
                bpy.ops.object.delete(use_global=True)
                bpy.ops.object.select_all(action='DESELECT')

    finder('*v_sleeve*')
    finder('*v_glove*')


def misc():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='*defuser*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='*decal*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='*sticker*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='*stattrack*', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def z_offset(name, value):
    bpy.data.objects[name].location.z = value


def anims_zero():
    print('\nCleaning done, now working with keyframes')
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='*.mdl*', case_sensitive=False, extend=True)
    bpy.context.scene.frame_current = 1
    selected_anims = bpy.context.selected_objects
    sel_anims = []
    for i in selected_anims:
        sel_anims.append(i.name)
    for a in sel_anims:
        bpy.ops.anim.keyframe_insert_menu(type='Location')
        bpy.data.objects[a].location = (0, 0, 0)
        z_offset(a, bpy.context.scene.offset)
        bpy.ops.anim.keyframe_insert_menu(type='Location')
    bpy.ops.object.select_all(action='DESELECT')
    print('\nYour scene is ready for export')


class Export_FBX_Vis(Operator, ExportHelper):
    bl_idname = "exp.fbx_vis"
    bl_label = "Export the scene"

    # ExportHelper mixin class uses this
    filename_ext = ".json"

    filter_glob: StringProperty(
        default="*.json",
        options={'HIDDEN'},
        maxlen=255,  # Max internal buffer length, longer would be clamped.
    )

    skeleton_name: StringProperty(
        name='Skeleton name',
        description='Skeleton name',
        default='root',
    )
    change_scale: FloatProperty(
        name='Export scale',
        description='Scales model_paths and animations',
        min=0.01, max=100000.0,
        soft_min=0.01, soft_max=100.0,
        default=1.0,
    )
    fixbones: BoolProperty(
        name='Fix bones',
        description='Use this only when you converted models with QC converter',
        default=True,
    )
    export_FBX: BoolProperty(
        name='Export FBX',
        description='Export all animations as fbx',
        default=True,
    )
    export_visibility: BoolProperty(
        name='Export visibility',
        description='Export visibility .json file',
        default=True,
    )

    @classmethod
    def description(cls, context, properties):
        return "Exports a JSON file that can later be used in Unreal"
    
    def execute(self, context):
        if not self.filepath.endswith("\\"):
            self.filepath = self.filepath.rsplit(sep="\\", maxsplit=1)[0] + "\\"

        if self.export_FBX:
            self.agr_to_fbx()
        if self.export_visibility:
            time_start = time.time()
            self.visibility_export()
            print('\n\nJSON file was exported in {:.2f} seconds'.format(time.time() - time_start))
        return {'FINISHED'}

    def agr_to_fbx(self):
        scn = bpy.context.scene

        def export_fbx(object_type, scale=1.0):
            bpy.ops.export_scene.fbx(
                filepath=fbx_filepath,
                use_selection=True,
                bake_anim_use_nla_strips=False,
                bake_anim_use_all_actions=False,
                bake_anim_simplify_factor=0,
                object_types={object_type},
                add_leaf_bones=False,
                global_scale=scale)

        for mesh in bpy.data.objects:

            fbx_filepath = self.filepath + '\\' + mesh.name + '.fbx'

            if mesh.name.startswith('afx'):
                mesh.select_set(True)
                old_root_name = mesh.name
                bpy.context.view_layer.objects.active = mesh
                if self.fixbones:
                    from . import Fix_Bones_CSGO
                    Fix_Bones_CSGO.main_fix(True, True)
                if '_skeleton' in mesh.data.name:
                    mesh.name = self.skeleton_name

                export_fbx('ARMATURE', self.change_scale)

                mesh.name = old_root_name
                mesh.select_set(False)

            elif mesh.name.startswith('camera') or mesh.name == 'afxCam':
                mesh.select_set(True)
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.data.objects[mesh.name].scale = (0.01, 0.01, 0.01)
                scn.frame_current = scn.frame_start
                bpy.ops.anim.keyframe_insert_menu(type='Scaling')
                export_fbx('CAMERA')
                bpy.data.objects[mesh.name].scale = (1, 1, 1)
                bpy.ops.anim.keyframe_insert_menu(type='Scaling')
                mesh.select_set(False)

    def visibility_export(self):
        bpy.ops.object.mode_set(mode='OBJECT')
        scn = bpy.context.scene  # current scene
        bpy.ops.object.select_pattern(pattern='*.mdl*', case_sensitive=False, extend=True)
        selected_anims = bpy.context.selected_objects  # get selected anims
        sel_anims = []
        vis_dict = {}

        for a in selected_anims:
            sel_anims.append(a.name)  # create list from selection

        print(f'\n\nExporting visibility')

        for frame in range(scn.frame_start, 2):
            scn.frame_set(frame)  # loop for frames
            for a in sel_anims:  # loop for selected anims
                vis_dict[a] = {}
                vis_dict[a][scn.frame_current] = str(bpy.context.scene.objects[a].hide_render)

        for frame in range(2, scn.frame_end):
            scn.frame_set(frame)  # loop for frames
            for a in sel_anims:  # loop for selected anims
                vis_dict[a][scn.frame_current] = str(bpy.context.scene.objects[a].hide_render)
            if frame % 50 == 0:
                percent = (frame / scn.frame_end) * 100
                print(f' {int(percent)}%...', end='')

        def clean(value, temp_dict):
            for k in temp_dict[:-1]:
                del value[k]

        def process(value):
            p = None
            temp_dict = []
            for k in list(value.keys()):
                if value[k] == p:
                    temp_dict.append(k)
                else:
                    clean(value, temp_dict)
                    p = value[k]
                    temp_dict = []
            clean(value, temp_dict)

        for v in vis_dict.values():
            process(v)

        export_file = open(self.filepath + '\\' + 'visibility.json', 'w')
        json.dump(vis_dict, export_file, sort_keys=False, indent=2)
        export_file.close()

    def draw(self, context):
        pass


class MENU_PT_export_fbx_settings(Panel):
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'TOOL_PROPS'
    bl_label = "Export FBX files"
    # bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        sfile = context.space_data
        operator = sfile.active_operator
        return operator.bl_idname == "EXP_OT_fbx_vis"

    def draw_header(self, context):
        sfile = context.space_data
        operator = sfile.active_operator

        self.layout.prop(operator, "export_FBX", text="")

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False  # No animation.

        sfile = context.space_data
        operator = sfile.active_operator
        layout.enabled = operator.export_FBX
        layout.prop(operator, 'skeleton_name')
        layout.prop(operator, "change_scale")
        layout.prop(operator, "fixbones")


class MENU_PT_export_visibility_settings(Panel):
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'TOOL_PROPS'
    bl_label = "Export vsibility"
    # bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        sfile = context.space_data
        operator = sfile.active_operator
        return operator.bl_idname == "EXP_OT_fbx_vis"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False  # No animation.

        sfile = context.space_data
        operator = sfile.active_operator
        layout.prop(operator, "export_visibility")


class CleanButton(Operator):
    bl_idname = 'opr.start_clean'
    bl_label = 'Clean'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        #bpy.ops.object.mode_set(mode='OBJECT')
        fixer()
        if context.scene.remove_w_knives:
            w_knives()
        if context.scene.remove_dropped_knives:
            w_knives_dropped()
        if context.scene.remove_w_guns:
            w_guns()
        if context.scene.remove_dropped_guns:
            w_guns_dropped()
        if context.scene.remove_w_pistols:
            w_pistols()
        if context.scene.remove_dropped_pistols:
            w_pistols_dropped()
        if context.scene.remove_w_nades:
            w_nades()
        if context.scene.remove_dropped_nades:
            w_nades_dropped()
        if context.scene.remove_w_c4:
            w_c4()
        if context.scene.remove_dropped_c4:
            w_c4_dropped()
        if context.scene.remove_pov:
            pov()
        if context.scene.remove_duplicates:
            duplicates()
        if context.scene.remove_misc:
            misc()
        if context.scene.place_animations:
            anims_zero()

        return {'FINISHED'}


class T_SidePanel(Panel):
    bl_idname = 'VIEW3D_PT_test_panel'
    bl_label = 'AGR tools'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'AGR tools'

    def draw(self, context):
        layout = self.layout.column(align=True)
        # layout.use_property_split = True
        # layout.use_property_decorate = False
        scene = context.scene

        def row_ui(row_prop, row1_prop):
            # layout.prop(scene, row_prop)
            row = layout.column(align=True).row(align=True)
            row.prop(scene, row_prop)
            row1 = row.row()
            # row1.enabled = prop_trigger
            row1.prop(scene, row1_prop)

            # layout.separator()

        def row_operator(row_operator, row1_operator):
            row = layout.column(align=True).row(align=True)
            row.operator(row_operator)
            row.operator(row1_operator)

        layout.label(text='Presets:')
        row_operator('opr.select_all', 'opr.deselect_all')
        row_operator('opr.pist_preset', 'opr.rif_preset')
        row_operator('opr.remove_all_w_preset', 'opr.remove_dropped_preset')
        row_operator('opr.pl_and_pov_preset', 'opr.pl_only_preset')
        layout.separator()

        layout.label(text='World weapons (thirdperson):')
        row_ui('remove_w_knives', 'remove_dropped_knives')
        row_ui('remove_w_guns', 'remove_dropped_guns')
        row_ui('remove_w_pistols', 'remove_dropped_pistols')
        row_ui('remove_w_nades', 'remove_dropped_nades')
        layout.separator()

        layout.label(text='Viewmodels (POV):')
        row_ui('remove_duplicates', 'remove_pov')
        layout.separator()

        layout.label(text='Misc:')
        layout.prop(scene, 'remove_misc')
        layout.prop(scene, 'place_animations')
        row = layout.column(align=True).row(align=True)
        row.enabled = scene.place_animations
        row.prop(scene, 'offset', text='Z Offset')
        layout.separator()

        layout.operator('opr.start_clean')
        layout.operator('exp.fbx_vis')


class PresetSelectAll(Operator):
    bl_idname = "opr.select_all"
    bl_label = "Select all"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.remove_w_knives = True
        context.scene.remove_dropped_knives = True
        context.scene.remove_w_guns = True
        context.scene.remove_dropped_guns = True
        context.scene.remove_w_pistols = True
        context.scene.remove_dropped_pistols = True
        context.scene.remove_w_nades = True
        context.scene.remove_dropped_nades = True
        context.scene.remove_w_c4 = True
        context.scene.remove_dropped_c4 = True
        context.scene.remove_pov = True
        context.scene.remove_misc = True
        context.scene.remove_duplicates = True
        context.scene.place_animations = True
        context.area.tag_redraw()
        return {'FINISHED'}


class PresetDeselectAll(Operator):
    bl_idname = "opr.deselect_all"
    bl_label = "Deselect all"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.remove_w_knives = False
        context.scene.remove_dropped_knives = False
        context.scene.remove_w_guns = False
        context.scene.remove_dropped_guns = False
        context.scene.remove_w_pistols = False
        context.scene.remove_dropped_pistols = False
        context.scene.remove_w_nades = False
        context.scene.remove_dropped_nades = False
        context.scene.remove_w_c4 = False
        context.scene.remove_dropped_c4 = False
        context.scene.remove_pov = False
        context.scene.remove_misc = False
        context.scene.remove_duplicates = False
        context.scene.place_animations = False
        context.area.tag_redraw()
        return {'FINISHED'}


class PresetPistolPreset(Operator):
    bl_idname = "opr.pist_preset"
    bl_label = "Pistol Kills"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.remove_w_knives = True
        context.scene.remove_dropped_knives = True
        context.scene.remove_w_guns = True
        context.scene.remove_dropped_guns = False
        context.scene.remove_w_pistols = True
        context.scene.remove_dropped_pistols = False
        context.scene.remove_w_nades = True
        context.scene.remove_dropped_nades = True
        context.scene.remove_w_c4 = False
        context.scene.remove_dropped_c4 = False
        context.scene.remove_pov = False
        context.scene.remove_misc = True
        context.scene.remove_duplicates = True
        context.scene.place_animations = True
        context.area.tag_redraw()
        return {'FINISHED'}


class PresetRifflePreset(Operator):
    bl_idname = "opr.rif_preset"
    bl_label = "Riffle kills"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.remove_w_knives = True
        context.scene.remove_dropped_knives = True
        context.scene.remove_w_guns = True
        context.scene.remove_dropped_guns = False
        context.scene.remove_w_pistols = True
        context.scene.remove_dropped_pistols = True
        context.scene.remove_w_nades = True
        context.scene.remove_dropped_nades = True
        context.scene.remove_w_c4 = False
        context.scene.remove_dropped_c4 = False
        context.scene.remove_pov = False
        context.scene.remove_misc = True
        context.scene.remove_duplicates = True
        context.scene.place_animations = True
        context.area.tag_redraw()
        return {'FINISHED'}


class PresetRemoveAllWPreset(Operator):
    bl_idname = "opr.remove_all_w_preset"
    bl_label = "Remove all weapons"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.remove_w_knives = True
        context.scene.remove_dropped_knives = False
        context.scene.remove_w_guns = True
        context.scene.remove_dropped_guns = False
        context.scene.remove_w_pistols = True
        context.scene.remove_dropped_pistols = False
        context.scene.remove_w_nades = True
        context.scene.remove_dropped_nades = False
        context.scene.remove_w_c4 = True
        context.scene.remove_dropped_c4 = False
        context.scene.remove_pov = False
        context.scene.remove_misc = True
        context.scene.remove_duplicates = True
        context.scene.place_animations = True
        context.area.tag_redraw()
        return {'FINISHED'}


class PresetRemoveAllDropped(Operator):
    bl_idname = "opr.remove_dropped_preset"
    bl_label = "Remove all dropped"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.remove_w_knives = False
        context.scene.remove_dropped_knives = True
        context.scene.remove_w_guns = False
        context.scene.remove_dropped_guns = True
        context.scene.remove_w_pistols = False
        context.scene.remove_dropped_pistols = True
        context.scene.remove_w_nades = False
        context.scene.remove_dropped_nades = True
        context.scene.remove_w_c4 = False
        context.scene.remove_dropped_c4 = True
        context.scene.remove_pov = False
        context.scene.remove_misc = True
        context.scene.remove_duplicates = True
        context.scene.place_animations = True
        context.area.tag_redraw()
        return {'FINISHED'}


class PresetPlayersAndPov(Operator):
    bl_idname = "opr.pl_and_pov_preset"
    bl_label = "Players and POV"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.remove_w_knives = True
        context.scene.remove_dropped_knives = True
        context.scene.remove_w_guns = True
        context.scene.remove_dropped_guns = True
        context.scene.remove_w_pistols = True
        context.scene.remove_dropped_pistols = True
        context.scene.remove_w_nades = True
        context.scene.remove_dropped_nades = True
        context.scene.remove_w_c4 = True
        context.scene.remove_dropped_c4 = True
        context.scene.remove_pov = False
        context.scene.remove_misc = True
        context.scene.remove_duplicates = True
        context.scene.place_animations = True
        context.area.tag_redraw()
        return {'FINISHED'}


class PresetPlayersOnly(Operator):
    bl_idname = "opr.pl_only_preset"
    bl_label = "Players Only"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.remove_w_knives = True
        context.scene.remove_dropped_knives = True
        context.scene.remove_w_guns = True
        context.scene.remove_dropped_guns = True
        context.scene.remove_w_pistols = True
        context.scene.remove_dropped_pistols = True
        context.scene.remove_w_nades = True
        context.scene.remove_dropped_nades = True
        context.scene.remove_w_c4 = True
        context.scene.remove_dropped_c4 = True
        context.scene.remove_pov = True
        context.scene.remove_misc = True
        context.scene.remove_duplicates = True
        context.scene.place_animations = True
        context.area.tag_redraw()
        return {'FINISHED'}


cLasses = [
    Export_FBX_Vis,
    MENU_PT_export_fbx_settings,
    MENU_PT_export_visibility_settings,
    T_SidePanel,
    CleanButton,
    PresetSelectAll,
    PresetDeselectAll,
    PresetPistolPreset,
    PresetRifflePreset,
    PresetRemoveAllWPreset,
    PresetRemoveAllDropped,
    PresetPlayersAndPov,
    PresetPlayersOnly,
    Convert_QC.QC_SMD_Convert,
    Convert_QC.QC_SMD_MENU_PT_convert_general_setings,
    Convert_QC.QC_SMD_MENU_PT_convert_model_setings,
    Convert_QC.QC_SMD_MENU_PT_convert_animation_setings
]


def register():
    for (prop_name, prop_value) in PROPS:
        setattr(bpy.types.Scene, prop_name, prop_value)
    for cls in cLasses:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(menu_draw_convert)


def unregister():
    for (prop_name, _) in PROPS:
        delattr(bpy.types.Scene, prop_name)
    for cls in cLasses:
        bpy.utils.unregister_class(cls)
    bpy.types.TOPBAR_MT_file_import.remove(menu_draw_convert)


if __name__ == '__main__':
    unregister()
    register()
