import bpy


def zero_frame(bone_name):
    scn = bpy.context.scene
    bpy.ops.object.mode_set(mode='POSE')
    scn.frame_end = 3
    for bones in bpy.data.armatures[0].bones:  # check if bone exists
        if bones.name == 'v_weapon.Bip01_L_Forearm':
            bpy.data.armatures[0].bones['v_weapon.Bip01_L_Forearm'].select = 1
            for frame in range(scn.frame_start, 3):
                scn.frame_set(frame)
                bpy.ops.anim.keyframe_insert_menu(type='Location')
                bpy.ops.anim.keyframe_insert_menu(type='Rotation')
                bpy.ops.anim.keyframe_insert_menu(type='Scaling')
                bpy.ops.anim.keyframe_insert_menu(type='Location')
            bpy.data.armatures[0].bones['v_weapon.Bip01_L_Forearm'].select = 0
            bpy.ops.object.mode_set(mode='OBJECT')
